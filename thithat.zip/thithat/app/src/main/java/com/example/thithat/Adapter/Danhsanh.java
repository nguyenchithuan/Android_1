package com.example.thithat.Adapter;

public class Danhsanh {
    String name;
    String nghe;

    public Danhsanh() {
    }

    public Danhsanh(String name, String nghe) {
        this.name = name;
        this.nghe = nghe;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNghe() {
        return nghe;
    }

    public void setNghe(String nghe) {
        this.nghe = nghe;
    }
}
